<?php
define('SWOOLE_LIBRARY', true);
